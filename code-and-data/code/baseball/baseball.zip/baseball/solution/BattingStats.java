import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/* 
 * MapReduce jobs are typically implemented by using a driver class.
 * The purpose of a driver class is to set up the configuration for the
 * MapReduce job and to run the job.
 * Typical requirements for a driver class include configuring the input
 * and output data formats, configuring the map and reduce classes,
 * and specifying intermediate data formats.
 * 
 * The following is the code for the driver class:
 */
public class BattingStats extends Configured implements Tool {

	@Override
	public int run(String[] args) throws Exception {

		/*
		 * The expected command-line arguments are the paths containing input
		 * and output data. Terminate the job if the number of command-line
		 * arguments is not exactly 2.
		 */
		if (args.length != 2) {
			System.out.printf("Usage: BattingStats <input dir> <output dir>\n");
			System.exit(-1);
		}

		/*
		 * Instantiate a Job object for your job's configuration.
		 */
		Job job = new Job();
		job.setJarByClass(BattingStats.class);
		job.setJobName("Batting Statistics");

		/*
		 * Specify the paths to the input and output data based on the
		 * command-line arguments.
		 */
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		/*
		 * Specify the mapper and reducer classes.
		 */
		job.setMapperClass(StatMapper.class);
		job.setReducerClass(StatReducer.class);

		/*
		 * REMEMBER: the mapper's output keys and values MUST have the same data
		 * types as the reducer's output keys and values!
		 * 
		 * When they are not the same data types, you must call the
		 * setMapOutputKeyClass and setMapOutputValueClass methods.
		 */

		/*
		 * Specify the job's output key and value classes.
		 */
		job.setOutputKeyClass(LongWritable.class);
		job.setOutputValueClass(LongWritable.class);

		/*
		 * Start the MapReduce job and wait for it to finish. If it finishes
		 * successfully, return 0. If not, return 1.
		 */
		return job.waitForCompletion(true) ? 0:1;
	}

	public static void main(String[] args) throws Exception {
		int result = ToolRunner.run(new BattingStats(), args);
		System.exit(result);
	}

}
