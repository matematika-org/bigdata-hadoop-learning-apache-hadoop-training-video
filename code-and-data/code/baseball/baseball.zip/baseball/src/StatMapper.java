import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParsePosition;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/* 
 * To define a map function for your MapReduce job, subclass 
 * the Mapper class and override the map method.
 * The class definition requires four parameters: 
 *   The data type of the input key
 *   The data type of the input value
 *   The data type of the output key (which is the input key type 
 *   for the reducer)
 *   The data type of the output value (which is the input value 
 *   type for the reducer)
 */

public class StatMapper extends
		Mapper<LongWritable, Text, LongWritable, LongWritable> {

	// Used below for number validation
	private static NumberFormat formatter = NumberFormat.getInstance();

	/*
	 * For purposes of object re-use, instantiate your reducer key & value
	 * objects here first
	 */
	// TODO

	/*
	 * The map method runs once for each line of text in the input file. The
	 * method receives a key of type LongWritable, a value of type Text, and a
	 * Context object.
	 */
	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {

		/*
		 * Convert the incoming line, which is received as a Text object, to a
		 * String array. The split() method uses a regular expression to split
		 * the line up by the incoming delimiter.
		 */
		// TODO

		/*
		 * Get data from the value array to send to the Reducer
		 * 
		 * Here, be careful to deal with null values, and skip the 1st line in
		 * the input file by checking columns (array elements) in the file.
		 * 
		 * HINT: Long.valueOf() converts a string value to a Long type, needed
		 * for a LongWritable. Also make sure the array values you expect
		 * to use are numeric, and neither null or empty.
		 */
		// TODO
	
	}

	/*
	 * Convenience method to validate a String type as numeric
	 */
	private static boolean isNumeric(String test) {
		if (test.isEmpty())
			return false;
		ParsePosition pos = new ParsePosition(0);
		formatter.parse(test, pos);
		return test.length() == pos.getIndex();
	}
}